import React, { useState } from 'react';
import { WEIGHT_PRESETS } from '../data/vegetables';
import { UnitType, BillItem } from '../types';
import { calculateVegetablePrice, generateConsoleBillText } from '../utils/calculator';
import {
  Calculator,
  Plus,
  Copy,
  Check,
  RotateCcw,
  Terminal,
  Receipt,
  IndianRupee,
  Scale,
  Sparkles,
} from 'lucide-react';

interface VegetableCalculatorProps {
  item: string;
  setItem: (val: string) => void;
  kgPrice: number | string;
  setKgPrice: (val: number | string) => void;
  quantity: number | string;
  setQuantity: (val: number | string) => void;
  unit: UnitType;
  setUnit: (val: UnitType) => void;
  onAddToCart: (item: BillItem) => void;
}

export const VegetableCalculator: React.FC<VegetableCalculatorProps> = ({
  item,
  setItem,
  kgPrice,
  setKgPrice,
  quantity,
  setQuantity,
  unit,
  setUnit,
  onAddToCart,
}) => {
  const [copiedConsole, setCopiedConsole] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  // Convert string inputs to safe numbers for math
  const numKgPrice = parseFloat(String(kgPrice)) || 0;
  const numQuantity = parseFloat(String(quantity)) || 0;

  // Real-time calculation matching python formula
  const calculation = calculateVegetablePrice(item, numKgPrice, numQuantity, unit);

  // Formatted Console text matching Python print statements
  const consoleBillText = generateConsoleBillText(
    calculation.item,
    calculation.customerGrams,
    calculation.totalPrice
  );

  const handleWeightPresetClick = (grams: number) => {
    if (unit === 'kg') {
      setQuantity(grams / 1000);
    } else {
      setQuantity(grams);
    }
  };

  const handleCopyConsoleBill = () => {
    navigator.clipboard.writeText(consoleBillText);
    setCopiedConsole(true);
    setTimeout(() => setCopiedConsole(false), 2000);
  };

  const handleAddBillItem = () => {
    if (!calculation.item || calculation.customerGrams <= 0 || calculation.kgPrice <= 0) {
      return;
    }

    const newItem: BillItem = {
      id: `bill-item-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      item: calculation.item,
      kgPrice: calculation.kgPrice,
      customerGrams: calculation.customerGrams,
      pricePerGram: calculation.pricePerGram,
      totalPrice: calculation.totalPrice,
      unit: unit,
      timestamp: new Date(),
    };

    onAddToCart(newItem);
    setAddedSuccess(true);
    setTimeout(() => setAddedSuccess(false), 1800);
  };

  const handleReset = () => {
    setItem('Tomato');
    setKgPrice(50);
    setQuantity(250);
    setUnit('g');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
      
      {/* Left Column: Interactive Form Inputs */}
      <div className="lg:col-span-7 space-y-5">
        <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm">
          
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                <Calculator className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  Vegetable Weight & Price Calculation
                </h3>
                <p className="text-xs text-slate-500">
                  Enter 1 kg rate and required weight in grams or kg
                </p>
              </div>
            </div>

            <button
              id="reset-calculator-btn"
              onClick={handleReset}
              className="text-xs text-slate-500 hover:text-slate-800 flex items-center gap-1 bg-slate-100 hover:bg-slate-200 px-2.5 py-1.5 rounded-lg transition-colors"
              title="Reset inputs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset
            </button>
          </div>

          <div className="space-y-4">
            
            {/* Input 1: Item Name */}
            <div>
              <label
                htmlFor="item-name-input"
                className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5"
              >
                1. Vegetable Name <span className="text-emerald-600">*</span>
              </label>
              <div className="relative">
                <input
                  id="item-name-input"
                  type="text"
                  placeholder="e.g. Tomato, Potato, Onion, Green Chili"
                  value={item}
                  onChange={(e) => setItem(e.target.value)}
                  className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 text-xs">
                  Item
                </div>
              </div>
            </div>

            {/* Input 2: 1 kg Price */}
            <div>
              <label
                htmlFor="kg-price-input"
                className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5"
              >
                2. Price for 1 kg (₹) <span className="text-emerald-600">*</span>
              </label>
              <div className="relative">
                <div className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-500 font-bold text-sm">
                  ₹
                </div>
                <input
                  id="kg-price-input"
                  type="number"
                  min="0"
                  step="0.5"
                  placeholder="e.g. 50"
                  value={kgPrice}
                  onChange={(e) => setKgPrice(e.target.value)}
                  className="w-full pl-8 pr-16 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-slate-400 bg-slate-200/60 px-2 py-0.5 rounded">
                  / 1000g
                </div>
              </div>
            </div>

            {/* Input 3: Required Weight & Unit */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label
                  htmlFor="customer-grams-input"
                  className="text-xs font-semibold text-slate-700 uppercase tracking-wider"
                >
                  3. Required Weight / Quantity <span className="text-emerald-600">*</span>
                </label>
                
                {/* Unit Switcher */}
                <div className="flex bg-slate-100 p-0.5 rounded-lg text-xs border border-slate-200">
                  <button
                    id="unit-g-btn"
                    onClick={() => setUnit('g')}
                    className={`px-2.5 py-0.5 rounded-md font-medium transition-colors ${
                      unit === 'g'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Grams (g)
                  </button>
                  <button
                    id="unit-kg-btn"
                    onClick={() => setUnit('kg')}
                    className={`px-2.5 py-0.5 rounded-md font-medium transition-colors ${
                      unit === 'kg'
                        ? 'bg-emerald-600 text-white shadow-xs'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    Kilograms (kg)
                  </button>
                </div>
              </div>

              <div className="relative">
                <input
                  id="customer-grams-input"
                  type="number"
                  min="0"
                  step={unit === 'kg' ? '0.05' : '5'}
                  placeholder={unit === 'g' ? 'e.g. 250' : 'e.g. 0.25'}
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full pl-3.5 pr-20 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                />
                <div className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md">
                  {unit === 'g' ? `${calculation.customerGrams} g` : `${numQuantity} kg`}
                </div>
              </div>
            </div>

            {/* Quick Weight Shortcut Chips */}
            <div>
              <span className="block text-[11px] font-medium text-slate-500 mb-1.5 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-emerald-600" />
                Quick Weight Shortcuts:
              </span>
              <div className="flex flex-wrap gap-1.5">
                {WEIGHT_PRESETS.map((preset) => (
                  <button
                    key={preset.grams}
                    id={`preset-weight-${preset.grams}`}
                    onClick={() => handleWeightPresetClick(preset.grams)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                      calculation.customerGrams === preset.grams
                        ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                        : 'bg-slate-50 hover:bg-emerald-50 border-slate-200 hover:border-emerald-300 text-slate-700'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

          </div>

          {/* Action Buttons */}
          <div className="mt-6 pt-4 border-t border-slate-100 flex flex-col sm:flex-row items-center gap-3">
            <button
              id="add-to-bill-btn"
              onClick={handleAddBillItem}
              disabled={calculation.customerGrams <= 0 || calculation.totalPrice <= 0}
              className={`w-full sm:w-auto flex-1 flex items-center justify-center gap-2 py-3 px-5 rounded-xl text-sm font-bold shadow-md transition-all ${
                addedSuccess
                  ? 'bg-emerald-800 text-white'
                  : 'bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              {addedSuccess ? (
                <>
                  <Check className="w-4 h-4 text-emerald-300" />
                  Added to Bill Cart!
                </>
              ) : (
                <>
                  <Plus className="w-4 h-4" />
                  Add Item to Bill
                </>
              )}
            </button>

            <button
              id="copy-terminal-bill-btn"
              onClick={handleCopyConsoleBill}
              className="w-full sm:w-auto flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-sm font-semibold bg-slate-900 text-slate-100 hover:bg-slate-800 transition-colors"
            >
              {copiedConsole ? (
                <>
                  <Check className="w-4 h-4 text-emerald-400" />
                  Copied Text!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-400" />
                  Copy Text Receipt
                </>
              )}
            </button>
          </div>

        </div>
      </div>

      {/* Right Column: Live Calculation Breakdown & Python Bill View */}
      <div className="lg:col-span-5 space-y-5">
        
        {/* Main Price Card */}
        <div className="bg-gradient-to-br from-emerald-900 via-emerald-950 to-slate-900 rounded-2xl p-6 text-white shadow-md relative overflow-hidden border border-emerald-800/80">
          <div className="absolute right-0 top-0 translate-x-4 -translate-y-4 opacity-10 pointer-events-none">
            <IndianRupee className="w-48 h-48 text-emerald-400" />
          </div>

          <div className="relative z-10">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-semibold uppercase tracking-wider text-emerald-300 bg-emerald-800/60 px-2.5 py-1 rounded-md border border-emerald-700/60">
                Calculated Total
              </span>
              <span className="text-xs text-emerald-300/80 font-mono">
                Formula: (1kg Price ÷ 1000) × Grams
              </span>
            </div>

            <div className="my-2">
              <div className="text-4xl sm:text-5xl font-black text-white tracking-tight flex items-baseline gap-1">
                <span className="text-emerald-400 text-3xl font-bold">₹</span>
                {calculation.totalPrice.toFixed(2)}
              </div>
              <p className="text-xs text-emerald-200 mt-1">
                For <span className="font-semibold text-white">{calculation.customerGrams} grams</span> of{' '}
                <span className="font-semibold text-white capitalize">{calculation.item}</span>
              </p>
            </div>

            {/* Formula Step-by-Step Breakdown */}
            <div className="mt-5 pt-4 border-t border-emerald-800/80 space-y-2 text-xs">
              <div className="flex justify-between items-center text-emerald-200">
                <span className="text-emerald-300">1 kg Rate:</span>
                <span className="font-semibold text-white">₹{calculation.kgPrice}</span>
              </div>
              <div className="flex justify-between items-center text-emerald-200">
                <span className="text-emerald-300">Price per Gram:</span>
                <span className="font-mono text-emerald-300">
                  ₹{calculation.pricePerGram.toFixed(4)} / gram
                </span>
              </div>
              <div className="flex justify-between items-center text-emerald-200 pt-1 border-t border-emerald-800/40">
                <span className="text-emerald-300">Math Step:</span>
                <span className="font-mono text-amber-300">
                  ₹{calculation.pricePerGram.toFixed(4)} × {calculation.customerGrams}g
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Console / Python Script Bill Output Box */}
        <div className="bg-slate-950 rounded-2xl border border-slate-800 p-4 font-mono text-xs shadow-sm">
          <div className="flex items-center justify-between mb-2.5 pb-2 border-b border-slate-800">
            <div className="flex items-center gap-2 text-slate-400">
              <Terminal className="w-3.5 h-3.5 text-emerald-400" />
              <span className="font-semibold text-[11px] tracking-wide text-slate-300 uppercase">
                Python Script Console Output
              </span>
            </div>
            <button
              id="copy-terminal-mini-btn"
              onClick={handleCopyConsoleBill}
              className="text-slate-400 hover:text-emerald-400 transition-colors"
              title="Copy Output"
            >
              {copiedConsole ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          </div>

          <pre className="bg-slate-900/90 text-emerald-400 p-3.5 rounded-xl border border-slate-800/80 overflow-x-auto leading-relaxed text-xs">
            {consoleBillText}
          </pre>

          <p className="text-[10px] text-slate-500 mt-2 text-center">
            Exact console format matching your Python script execution
          </p>
        </div>

      </div>

    </div>
  );
};
