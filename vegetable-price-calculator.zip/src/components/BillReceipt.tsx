import React, { useState, useEffect } from 'react';
import { BillItem, PaymentMethod } from '../types';
import { generateMultiItemReceiptText, generateConsoleBillText } from '../utils/calculator';
import {
  ReceiptText,
  Trash2,
  Printer,
  Copy,
  Check,
  Plus,
  Minus,
  ShoppingBag,
  IndianRupee,
  Store,
  Percent,
  QrCode,
  CreditCard,
  Banknote,
  CheckCircle2,
  Clock,
  ExternalLink,
} from 'lucide-react';

interface BillReceiptProps {
  items: BillItem[];
  onRemoveItem: (id: string) => void;
  onUpdateItemQuantity?: (id: string, newGrams: number) => void;
  onClearCart: () => void;
  onSwitchToCalculator: () => void;
}

const LOCAL_STORAGE_UPI_KEY = 'sabzi_store_upi_id';

export const BillReceipt: React.FC<BillReceiptProps> = ({
  items,
  onRemoveItem,
  onUpdateItemQuantity,
  onClearCart,
  onSwitchToCalculator,
}) => {
  const [cashTendered, setCashTendered] = useState<string>('');
  const [storeName, setStoreName] = useState<string>('GREEN VEGETABLE MARKET');
  const [gstPercent, setGstPercent] = useState<number | string>(0);
  const [copied, setCopied] = useState(false);
  const [viewMode, setViewMode] = useState<'receipt' | 'console'>('receipt');

  // Payment Method States
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [paymentStatus, setPaymentStatus] = useState<'paid' | 'pending'>('pending');
  const [upiId, setUpiId] = useState<string>(() => {
    try {
      return localStorage.getItem(LOCAL_STORAGE_UPI_KEY) || 'market@upi';
    } catch {
      return 'market@upi';
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_UPI_KEY, upiId);
    } catch (e) {
      console.error('Failed to save UPI ID to localStorage', e);
    }
  }, [upiId]);

  const subtotal = items.reduce((sum, item) => sum + item.totalPrice, 0);
  const totalGrams = items.reduce((sum, item) => sum + item.customerGrams, 0);

  const gstRateNum = Math.max(0, parseFloat(String(gstPercent)) || 0);
  const taxAmount = (subtotal * gstRateNum) / 100;
  const finalGrandTotal = subtotal + taxAmount;

  const cashNum = parseFloat(cashTendered) || 0;
  const changeToReturn = cashNum > 0 ? cashNum - finalGrandTotal : 0;

  // UPI Link & Scannable QR Code URL
  const upiUri = `upi://pay?pa=${encodeURIComponent(upiId)}&pn=${encodeURIComponent(storeName)}&am=${finalGrandTotal.toFixed(2)}&cu=INR&tn=${encodeURIComponent('Supermarket Bill')}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=220x220&data=${encodeURIComponent(upiUri)}`;

  const fullReceiptText = generateMultiItemReceiptText(
    items,
    storeName,
    gstRateNum,
    paymentMethod,
    paymentStatus,
    upiId
  );

  const handleCopyReceipt = () => {
    navigator.clipboard.writeText(fullReceiptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleQuantityChange = (id: string, newGrams: number) => {
    if (onUpdateItemQuantity) {
      onUpdateItemQuantity(id, Math.max(0, newGrams));
    }
  };

  return (
    <div className="space-y-6">
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl border border-slate-200/90 shadow-sm">
        <div>
          <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
            <ReceiptText className="w-5 h-5 text-emerald-600" />
            Customer Bill & POS Checkout
          </h2>
          <p className="text-xs text-slate-500">
            {items.length === 0
              ? 'Your cart is currently empty'
              : `${items.length} item(s) in bill • Total weight: ${
                  totalGrams >= 1000 ? `${(totalGrams / 1000).toFixed(2)} kg` : `${totalGrams} g`
                }`}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {items.length > 0 && (
            <button
              id="clear-cart-btn"
              onClick={onClearCart}
              className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg border border-rose-200 transition-colors flex items-center gap-1"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear Bill
            </button>
          )}

          <button
            id="add-more-items-btn"
            onClick={onSwitchToCalculator}
            className="px-3 py-1.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg transition-colors flex items-center gap-1 shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            Calculate More Items
          </button>
        </div>
      </div>

      {items.length === 0 ? (
        <div className="no-print bg-white rounded-2xl border border-slate-200 p-8 sm:p-12 text-center max-w-lg mx-auto space-y-4">
          <div className="w-16 h-16 rounded-full bg-emerald-50 border border-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
            <ShoppingBag className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-slate-800">No Vegetables or Products Added</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-xs mx-auto">
              Use the Calculator or Product Catalog to add groceries, dairy, and vegetables to your bill.
            </p>
          </div>
          <button
            id="start-calculating-btn"
            onClick={onSwitchToCalculator}
            className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-sm transition-all"
          >
            <Plus className="w-4 h-4" />
            Start Calculating Now
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Itemized Table & Payment Controls */}
          <div className="lg:col-span-7 space-y-5 no-print">
            
            {/* Table */}
            <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Bill Items ({items.length})
                </span>
                <span className="text-xs font-semibold text-emerald-700">
                  Total Weight: {totalGrams >= 1000 ? `${(totalGrams / 1000).toFixed(2)} kg` : `${totalGrams} g`}
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 text-slate-500 font-semibold border-b border-slate-100">
                    <tr>
                      <th className="py-3 px-4">Item</th>
                      <th className="py-3 px-3 text-right">1 kg / Unit Rate</th>
                      <th className="py-3 px-3 text-center">Quantity (g)</th>
                      <th className="py-3 px-4 text-right">Total (₹)</th>
                      <th className="py-3 px-3 text-center">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {items.map((it, idx) => (
                      <tr key={it.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="py-3 px-4 font-semibold text-slate-800">
                          <span className="text-slate-400 font-normal mr-1.5">{idx + 1}.</span>
                          {it.item}
                        </td>
                        <td className="py-3 px-3 text-right text-slate-600 font-mono">
                          ₹{it.kgPrice}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <div className="inline-flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200">
                            <button
                              id={`decrease-qty-btn-${it.id}`}
                              onClick={() => handleQuantityChange(it.id, Math.max(0, it.customerGrams - 50))}
                              className="w-6 h-6 rounded-md bg-white hover:bg-rose-50 hover:text-rose-600 text-slate-600 font-bold flex items-center justify-center transition-colors shadow-2xs text-xs"
                              title="Decrease 50g"
                            >
                              <Minus className="w-3 h-3" />
                            </button>

                            <input
                              id={`qty-input-${it.id}`}
                              type="number"
                              min="0"
                              step="25"
                              value={it.customerGrams}
                              onChange={(e) =>
                                handleQuantityChange(it.id, Math.max(0, parseFloat(e.target.value) || 0))
                              }
                              className="w-16 text-center font-bold font-mono text-xs bg-transparent focus:outline-none focus:bg-white rounded py-0.5"
                            />
                            <span className="text-[10px] text-slate-500 font-medium mr-1">g</span>

                            <button
                              id={`increase-qty-btn-${it.id}`}
                              onClick={() => handleQuantityChange(it.id, it.customerGrams + 50)}
                              className="w-6 h-6 rounded-md bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-600 font-bold flex items-center justify-center transition-colors shadow-2xs text-xs"
                              title="Increase 50g"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>
                        </td>
                        <td className="py-3 px-4 text-right font-bold text-emerald-700 font-mono text-sm">
                          ₹{it.totalPrice.toFixed(2)}
                        </td>
                        <td className="py-3 px-3 text-center">
                          <button
                            id={`remove-item-btn-${it.id}`}
                            onClick={() => onRemoveItem(it.id)}
                            className="text-slate-400 hover:text-rose-600 p-1 rounded-md hover:bg-rose-50 transition-colors"
                            title="Remove item"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="bg-emerald-50/50 border-t-2 border-emerald-100 font-bold text-xs">
                    <tr>
                      <td colSpan={3} className="py-2.5 px-4 text-slate-700">
                        Subtotal Amount:
                      </td>
                      <td className="py-2.5 px-4 text-right text-slate-800 font-mono">
                        ₹{subtotal.toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                    {gstRateNum > 0 && (
                      <tr>
                        <td colSpan={3} className="py-2 px-4 text-emerald-800 font-medium">
                          GST / Tax ({gstRateNum}%):
                        </td>
                        <td className="py-2 px-4 text-right text-emerald-700 font-mono">
                          +₹{taxAmount.toFixed(2)}
                        </td>
                        <td></td>
                      </tr>
                    )}
                    <tr className="bg-emerald-100/60 text-sm">
                      <td colSpan={3} className="py-3.5 px-4 text-emerald-950">
                        Final Grand Total:
                      </td>
                      <td className="py-3.5 px-4 text-right text-emerald-900 text-base font-mono">
                        ₹{finalGrandTotal.toFixed(2)}
                      </td>
                      <td></td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {/* GST / Tax Rate Input */}
            <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Percent className="w-4 h-4 text-emerald-600" />
                  GST / Tax Rate Calculation
                </h3>
                {gstRateNum > 0 && (
                  <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    Tax Added: +₹{taxAmount.toFixed(2)}
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <div className="flex items-center gap-1.5 max-w-[180px]">
                  <input
                    id="gst-input"
                    type="number"
                    min="0"
                    max="100"
                    step="0.5"
                    placeholder="0"
                    value={gstPercent}
                    onChange={(e) => setGstPercent(e.target.value)}
                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                  <span className="text-xs font-bold text-slate-600">%</span>
                </div>

                <div className="flex items-center gap-1.5">
                  {[0, 5, 12, 18].map((rate) => (
                    <button
                      key={rate}
                      id={`gst-preset-btn-${rate}`}
                      onClick={() => setGstPercent(rate)}
                      className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition-colors ${
                        Number(gstPercent) === rate
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                      }`}
                    >
                      {rate}%
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Payment Method Selector & COD / UPI Options */}
            <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-sm space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  Select Payment Method
                </h3>

                {/* Paid Status Toggle */}
                <button
                  id="toggle-payment-status-btn"
                  onClick={() => setPaymentStatus(paymentStatus === 'paid' ? 'pending' : 'paid')}
                  className={`flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                    paymentStatus === 'paid'
                      ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                      : 'bg-amber-100 text-amber-800 border border-amber-300'
                  }`}
                >
                  {paymentStatus === 'paid' ? (
                    <>
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      Payment Marked PAID ✓
                    </>
                  ) : (
                    <>
                      <Clock className="w-3.5 h-3.5 text-amber-600" />
                      Status: PENDING
                    </>
                  )}
                </button>
              </div>

              {/* COD vs Online UPI Tabs */}
              <div className="grid grid-cols-2 gap-3">
                <button
                  id="pay-method-cash-btn"
                  type="button"
                  onClick={() => setPaymentMethod('cash')}
                  className={`flex items-center justify-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition-all ${
                    paymentMethod === 'cash'
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 ring-2 ring-emerald-500/20 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-700'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-emerald-600" />
                  Cash on Delivery (COD)
                </button>

                <button
                  id="pay-method-upi-btn"
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`flex items-center justify-center gap-2.5 p-3 rounded-xl border text-xs font-bold transition-all ${
                    paymentMethod === 'upi'
                      ? 'border-emerald-600 bg-emerald-50/80 text-emerald-900 ring-2 ring-emerald-500/20 shadow-2xs'
                      : 'border-slate-200 hover:border-slate-300 bg-slate-50 text-slate-700'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-emerald-600" />
                  Online Payment (UPI QR)
                </button>
              </div>

              {/* Cash Payment Options */}
              {paymentMethod === 'cash' && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
                  <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                    <IndianRupee className="w-3.5 h-3.5 text-emerald-600" />
                    Cash / COD Change Calculator
                  </h4>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label htmlFor="cash-tendered-input" className="block text-[11px] font-semibold text-slate-600 mb-1">
                        Cash Received from Customer (₹)
                      </label>
                      <input
                        id="cash-tendered-input"
                        type="number"
                        min="0"
                        placeholder="e.g. 100, 200, 500"
                        value={cashTendered}
                        onChange={(e) => setCashTendered(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                      />
                      
                      <div className="flex gap-1.5 mt-2">
                        {[50, 100, 200, 500].map((note) => (
                          <button
                            key={note}
                            id={`cash-note-btn-${note}`}
                            onClick={() => setCashTendered(String(note))}
                            className="px-2 py-0.5 text-[10px] font-semibold bg-white hover:bg-emerald-100 hover:text-emerald-800 text-slate-700 rounded-md border border-slate-200 transition-colors"
                          >
                            ₹{note}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-col justify-center">
                      <span className="text-[11px] font-medium text-slate-500">Change to Return to Customer:</span>
                      <div className={`text-xl font-bold font-mono mt-0.5 ${changeToReturn >= 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                        {cashNum > 0 ? `₹${changeToReturn.toFixed(2)}` : '₹0.00'}
                      </div>
                      {cashNum > 0 && changeToReturn < 0 && (
                        <span className="text-[10px] text-rose-600 font-medium">
                          Short by ₹{Math.abs(changeToReturn).toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* Online Payment (UPI / QR) Options */}
              {paymentMethod === 'upi' && (
                <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-4">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                        <QrCode className="w-4 h-4 text-emerald-600" />
                        Online Payment via Scannable UPI QR Code
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Customers can scan with Google Pay, PhonePe, Paytm or BHIM
                      </p>
                    </div>

                    <div className="w-full sm:w-auto">
                      <label htmlFor="upi-id-input" className="block text-[10px] font-bold text-slate-600 uppercase mb-0.5">
                        Merchant UPI ID:
                      </label>
                      <input
                        id="upi-id-input"
                        type="text"
                        placeholder="market@upi"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                        className="w-full sm:w-44 px-2.5 py-1 text-xs font-mono font-bold bg-white border border-slate-300 rounded-lg text-emerald-800 focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center gap-5 bg-white p-4 rounded-xl border border-slate-200">
                    {/* Live Generated QR Code */}
                    <div className="flex flex-col items-center">
                      <div className="p-2 bg-white rounded-xl border-2 border-emerald-500 shadow-sm">
                        <img
                          src={qrCodeUrl}
                          alt="UPI QR Code"
                          className="w-36 h-36 object-contain"
                        />
                      </div>
                      <span className="text-[10px] font-bold font-mono text-slate-600 mt-1">
                        Scan & Pay ₹{finalGrandTotal.toFixed(2)}
                      </span>
                    </div>

                    {/* Quick Pay Info & Deep Links */}
                    <div className="flex-1 space-y-2.5 w-full">
                      <div className="bg-emerald-50 p-2.5 rounded-xl border border-emerald-200">
                        <div className="text-[11px] font-semibold text-emerald-900">
                          Amount to Pay: <span className="font-mono font-bold text-sm">₹{finalGrandTotal.toFixed(2)}</span>
                        </div>
                        <div className="text-[10px] text-emerald-700 font-mono truncate">
                          Payee: {storeName} ({upiId})
                        </div>
                      </div>

                      {/* Direct UPI App Buttons */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase text-slate-500">
                          Direct App Links (Mobile Users):
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          <a
                            href={upiUri}
                            className="px-2.5 py-1 bg-slate-100 hover:bg-emerald-100 text-slate-800 hover:text-emerald-900 text-[11px] font-bold rounded-lg border border-slate-200 flex items-center gap-1"
                          >
                            <ExternalLink className="w-3 h-3 text-emerald-600" />
                            GPay / PhonePe / Paytm
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

            </div>

          </div>

          {/* Printable Receipt Preview Panel */}
          <div className="lg:col-span-5 space-y-4">
            
            <div className="bg-slate-900 text-slate-100 rounded-2xl p-5 shadow-lg border border-slate-800 space-y-4 no-print">
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                  <Store className="w-4 h-4" />
                  Receipt Preview
                </div>

                <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-lg text-[10px]">
                  <button
                    id="view-receipt-styled"
                    onClick={() => setViewMode('receipt')}
                    className={`px-2 py-1 rounded-md font-medium transition-colors ${
                      viewMode === 'receipt'
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    POS Receipt
                  </button>
                  <button
                    id="view-receipt-console"
                    onClick={() => setViewMode('console')}
                    className={`px-2 py-1 rounded-md font-medium transition-colors ${
                      viewMode === 'console'
                        ? 'bg-emerald-600 text-white font-bold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Python Format
                  </button>
                </div>
              </div>

              {/* Editable Store Header */}
              <div>
                <label htmlFor="store-name-input" className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                  Custom Store Header Name:
                </label>
                <input
                  id="store-name-input"
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  className="w-full px-2.5 py-1 text-xs bg-slate-800 border border-slate-700 rounded-lg text-slate-200 focus:outline-none focus:border-emerald-500 font-semibold"
                />
              </div>

              {/* Thermal Paper / Terminal Preview Card */}
              {viewMode === 'receipt' ? (
                <div className="bg-amber-50 text-slate-900 rounded-xl p-5 font-mono text-xs shadow-inner border border-amber-200/80 leading-relaxed space-y-3">
                  <div className="text-center pb-3 border-b border-dashed border-slate-400 space-y-1">
                    <h4 className="font-bold text-sm tracking-wider uppercase text-slate-900">
                      {storeName || 'GREEN MARKET'}
                    </h4>
                    <p className="text-[10px] text-slate-600">Fresh Vegetables & Essentials</p>
                    <p className="text-[10px] text-slate-500">
                      {new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}
                    </p>
                  </div>

                  <div className="py-2 space-y-1.5 border-b border-dashed border-slate-400">
                    <div className="flex justify-between font-bold text-[10px] text-slate-600 uppercase">
                      <span>Item</span>
                      <span>Rate & Weight</span>
                      <span>Total</span>
                    </div>

                    {items.map((it) => (
                      <div key={it.id} className="flex justify-between text-xs">
                        <span className="font-semibold text-slate-800 capitalize truncate max-w-[120px]">
                          {it.item}
                        </span>
                        <span className="text-slate-600 text-[11px]">
                          {it.customerGrams}g @ ₹{it.kgPrice}/kg
                        </span>
                        <span className="font-bold text-slate-900">
                          ₹{it.totalPrice.toFixed(2)}
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="space-y-1">
                    <div className="flex justify-between text-xs text-slate-700 font-medium">
                      <span>Subtotal:</span>
                      <span>₹{subtotal.toFixed(2)}</span>
                    </div>

                    {gstRateNum > 0 && (
                      <div className="flex justify-between text-xs text-slate-700">
                        <span>GST / Tax ({gstRateNum}%):</span>
                        <span>₹{taxAmount.toFixed(2)}</span>
                      </div>
                    )}

                    <div className="flex justify-between font-bold text-sm text-slate-900 pt-1 border-t border-slate-300">
                      <span>GRAND TOTAL:</span>
                      <span>₹{finalGrandTotal.toFixed(2)}</span>
                    </div>

                    <div className="pt-2 border-t border-dashed border-slate-300 text-[11px] space-y-0.5">
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>PAYMENT METHOD:</span>
                        <span>{paymentMethod === 'upi' ? 'ONLINE UPI' : 'CASH / COD'}</span>
                      </div>
                      {paymentMethod === 'upi' && (
                        <div className="flex justify-between text-[10px] text-slate-600">
                          <span>UPI VPA:</span>
                          <span>{upiId}</span>
                        </div>
                      )}
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>PAYMENT STATUS:</span>
                        <span className={paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'}>
                          {paymentStatus === 'paid' ? 'PAID ✓' : 'PENDING ⏳'}
                        </span>
                      </div>
                    </div>

                    {paymentMethod === 'cash' && cashNum > 0 && (
                      <div className="pt-1 text-[11px] border-t border-slate-200">
                        <div className="flex justify-between text-slate-600">
                          <span>Cash Received:</span>
                          <span>₹{cashNum.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between font-bold text-emerald-800">
                          <span>Change Returned:</span>
                          <span>₹{changeToReturn.toFixed(2)}</span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* QR Code in POS Receipt View if UPI selected */}
                  {paymentMethod === 'upi' && (
                    <div className="flex flex-col items-center pt-2 border-t border-dashed border-slate-400">
                      <img
                        src={qrCodeUrl}
                        alt="UPI QR Code"
                        className="w-24 h-24 object-contain"
                      />
                      <span className="text-[9px] font-bold text-slate-600 mt-1">
                        SCAN TO PAY ₹{finalGrandTotal.toFixed(2)}
                      </span>
                    </div>
                  )}

                  <div className="text-center pt-3 border-t border-dashed border-slate-400 text-[10px] text-slate-500 uppercase tracking-widest mt-2">
                    *** Thank You! Visit Again ***
                  </div>
                </div>
              ) : (
                <div className="bg-slate-950 p-3.5 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 space-y-2 overflow-x-auto">
                  {items.map((it) => (
                    <div key={it.id} className="pb-2 border-b border-slate-800/60 last:border-0">
                      <div>{generateConsoleBillText(it.item, it.customerGrams, it.totalPrice)}</div>
                    </div>
                  ))}
                  {gstRateNum > 0 && (
                    <div className="pt-2 text-slate-300">
                      Tax ({gstRateNum}%): ₹{taxAmount.toFixed(2)}
                    </div>
                  )}
                  <div className="font-bold text-white">
                    Grand Total: ₹{finalGrandTotal.toFixed(2)}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  id="print-receipt-btn"
                  onClick={handlePrint}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400 transition-colors shadow-sm"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Receipt
                </button>

                <button
                  id="copy-receipt-btn"
                  onClick={handleCopyReceipt}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl text-xs font-semibold bg-slate-800 text-slate-200 hover:bg-slate-700 transition-colors"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-400" />
                      Copy Bill Text
                    </>
                  )}
                </button>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* Printable Thermal Receipt DOM element (visible only during print) */}
      <div className="hidden print-only print-container bg-white text-slate-900 p-4 font-mono text-xs">
        <div className="text-center pb-2 border-b border-dashed border-slate-400">
          <h3 className="font-bold text-base uppercase">{storeName || 'GREEN VEGETABLE MARKET'}</h3>
          <p className="text-[10px]">Fresh Vegetables & Essentials</p>
          <p className="text-[10px]">{new Date().toLocaleString('en-IN', { dateStyle: 'medium', timeStyle: 'short' })}</p>
        </div>

        <div className="py-2 border-b border-dashed border-slate-400 space-y-1">
          <div className="flex justify-between font-bold text-[10px]">
            <span>ITEM</span>
            <span>QTY @ RATE</span>
            <span>TOTAL</span>
          </div>
          {items.map((it) => (
            <div key={it.id} className="flex justify-between">
              <span>{it.item}</span>
              <span>{it.customerGrams}g @ ₹{it.kgPrice}/kg</span>
              <span>₹{it.totalPrice.toFixed(2)}</span>
            </div>
          ))}
        </div>

        <div className="pt-2 space-y-1">
          <div className="flex justify-between">
            <span>Subtotal:</span>
            <span>₹{subtotal.toFixed(2)}</span>
          </div>
          {gstRateNum > 0 && (
            <div className="flex justify-between">
              <span>GST/Tax ({gstRateNum}%):</span>
              <span>₹{taxAmount.toFixed(2)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-sm border-t border-slate-300 pt-1">
            <span>TOTAL:</span>
            <span>₹{finalGrandTotal.toFixed(2)}</span>
          </div>

          <div className="pt-1 border-t border-dashed border-slate-300 text-[10px]">
            <div className="flex justify-between font-bold">
              <span>PAYMENT METHOD:</span>
              <span>{paymentMethod === 'upi' ? 'ONLINE UPI' : 'CASH / COD'}</span>
            </div>
            {paymentMethod === 'upi' && (
              <div className="flex justify-between">
                <span>UPI ID:</span>
                <span>{upiId}</span>
              </div>
            )}
            <div className="flex justify-between font-bold">
              <span>STATUS:</span>
              <span>{paymentStatus === 'paid' ? 'PAID ✓' : 'PENDING ⏳'}</span>
            </div>
          </div>

          {paymentMethod === 'cash' && cashNum > 0 && (
            <>
              <div className="flex justify-between">
                <span>Cash Received:</span>
                <span>₹{cashNum.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>Change Returned:</span>
                <span>₹{changeToReturn.toFixed(2)}</span>
              </div>
            </>
          )}
        </div>

        {paymentMethod === 'upi' && (
          <div className="flex flex-col items-center my-2 pt-2 border-t border-dashed border-slate-400">
            <img src={qrCodeUrl} alt="UPI QR" className="w-24 h-24 object-contain" />
            <span className="text-[9px] font-bold mt-1">SCAN & PAY ₹{finalGrandTotal.toFixed(2)}</span>
          </div>
        )}

        <div className="text-center pt-3 border-t border-dashed border-slate-400 text-[10px] mt-2 uppercase">
          *** Thank You! Visit Again ***
        </div>
      </div>

    </div>
  );
};

