import React from 'react';
import { Scale, IndianRupee, Sparkles } from 'lucide-react';

interface PriceMatrixProps {
  item: string;
  kgPrice: number;
}

export const PriceMatrix: React.FC<PriceMatrixProps> = ({ item, kgPrice }) => {
  const safeRate = Math.max(0, kgPrice || 0);
  const pricePerGram = safeRate / 1000;

  const weights = [
    { label: '50 grams', grams: 50, note: 'Small quantity' },
    { label: '100 grams', grams: 100, note: '1/10th kg' },
    { label: '200 grams', grams: 200, note: '200g' },
    { label: '250 grams', grams: 250, note: '1/4 kg (Paau)' },
    { label: '500 grams', grams: 500, note: '1/2 kg (Aadha)' },
    { label: '750 grams', grams: 750, note: '3/4 kg (Pawn)' },
    { label: '1.0 kg', grams: 1000, note: '1000 grams' },
    { label: '1.5 kg', grams: 1500, note: '1500 grams' },
    { label: '2.0 kg', grams: 2000, note: '2000 grams' },
    { label: '3.0 kg', grams: 3000, note: '3000 grams' },
    { label: '5.0 kg', grams: 5000, note: '5000 grams' },
    { label: '10.0 kg', grams: 10000, note: '10,000 grams (Bag)' },
  ];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm space-y-5 max-w-4xl mx-auto">
      
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
              Weight-to-Price Rate Chart: <span className="text-emerald-700 capitalize">{item || 'Vegetable'}</span>
            </h2>
            <p className="text-xs text-slate-500">
              Quick glance reference price matrix at <span className="font-semibold text-slate-800">₹{safeRate} / kg</span> (₹{pricePerGram.toFixed(4)}/g)
            </p>
          </div>
        </div>

        <div className="bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 text-xs font-bold text-emerald-800 self-start sm:self-auto">
          Base Rate: ₹{safeRate}/kg
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
        {weights.map((w) => {
          const total = pricePerGram * w.grams;
          const isStandardHalf = w.grams === 500;
          const isStandardQuarter = w.grams === 250;
          const isOneKg = w.grams === 1000;

          return (
            <div
              key={w.grams}
              className={`p-3.5 rounded-xl border transition-all ${
                isOneKg
                  ? 'bg-emerald-900 text-white border-emerald-800 ring-2 ring-emerald-500/30'
                  : isStandardHalf || isStandardQuarter
                  ? 'bg-emerald-50/80 border-emerald-200 text-slate-900'
                  : 'bg-slate-50 border-slate-200/80 text-slate-800'
              }`}
            >
              <div className="flex items-center justify-between text-xs font-medium opacity-80 mb-1">
                <span>{w.label}</span>
                <span className="text-[10px] font-mono">{w.note}</span>
              </div>
              <div className={`text-xl font-bold font-mono ${isOneKg ? 'text-amber-300' : 'text-emerald-700'}`}>
                ₹{total.toFixed(2)}
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
