import React, { useState, useEffect } from 'react';
import { ShoppingBag, Scale, Sparkles, ReceiptText, Calculator } from 'lucide-react';

interface HeaderProps {
  cartItemCount: number;
  activeTab: 'calculator' | 'multi-bill' | 'budget' | 'matrix';
  setActiveTab: (tab: 'calculator' | 'multi-bill' | 'budget' | 'matrix') => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartItemCount,
  activeTab,
  setActiveTab,
}) => {
  const [time, setTime] = useState<string>('');

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setTime(
        now.toLocaleTimeString('en-IN', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          hour12: true,
        })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="bg-emerald-900 text-emerald-50 border-b border-emerald-800 shadow-sm sticky top-0 z-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-emerald-500/20 border border-emerald-400/30 flex items-center justify-center text-emerald-300 shadow-inner">
              <Scale className="w-6 h-6 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-1.5">
                  Sabzi Price & Grams Calculator
                </h1>
                <span className="hidden md:inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-emerald-800 text-emerald-200 border border-emerald-700">
                  ₹ / Gram Rate Engine
                </span>
              </div>
              <p className="text-xs text-emerald-300/80">
                Vegetable Weight, Price per Gram & Bill Generator
              </p>
            </div>
          </div>

          {/* Time & Quick Stats */}
          <div className="flex items-center gap-3 self-end sm:self-auto text-xs">
            <div className="hidden lg:flex items-center gap-1.5 bg-emerald-950/60 px-3 py-1.5 rounded-lg border border-emerald-800/80 text-emerald-200">
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span>1 kg = 1000 grams</span>
            </div>
            <div className="bg-emerald-950/80 px-3 py-1.5 rounded-lg border border-emerald-800 text-emerald-300 font-mono font-medium">
              {time || '00:00:00 AM'}
            </div>
          </div>
        </div>

        {/* Navigation Tabs */}
        <nav className="flex items-center gap-1 mt-3.5 pt-2 border-t border-emerald-800/60 overflow-x-auto no-scrollbar">
          <button
            id="tab-calculator"
            onClick={() => setActiveTab('calculator')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === 'calculator'
                ? 'bg-emerald-500 text-emerald-950 shadow-sm font-semibold'
                : 'text-emerald-200 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <Calculator className="w-4 h-4" />
            Single Item Calculator
          </button>

          <button
            id="tab-multi-bill"
            onClick={() => setActiveTab('multi-bill')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap relative ${
              activeTab === 'multi-bill'
                ? 'bg-emerald-500 text-emerald-950 shadow-sm font-semibold'
                : 'text-emerald-200 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <ReceiptText className="w-4 h-4" />
            Bill & Cart
            {cartItemCount > 0 && (
              <span className="ml-1 bg-amber-400 text-amber-950 text-[10px] font-bold px-1.5 py-0.2 rounded-full min-w-[18px] text-center">
                {cartItemCount}
              </span>
            )}
          </button>

          <button
            id="tab-budget"
            onClick={() => setActiveTab('budget')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === 'budget'
                ? 'bg-emerald-500 text-emerald-950 shadow-sm font-semibold'
                : 'text-emerald-200 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <ShoppingBag className="w-4 h-4" />
            Fixed Budget to Grams
          </button>

          <button
            id="tab-matrix"
            onClick={() => setActiveTab('matrix')}
            className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs sm:text-sm font-medium transition-all whitespace-nowrap ${
              activeTab === 'matrix'
                ? 'bg-emerald-500 text-emerald-950 shadow-sm font-semibold'
                : 'text-emerald-200 hover:bg-emerald-800/60 hover:text-white'
            }`}
          >
            <Scale className="w-4 h-4" />
            Weight-Price Reference Matrix
          </button>
        </nav>
      </div>
    </header>
  );
};
