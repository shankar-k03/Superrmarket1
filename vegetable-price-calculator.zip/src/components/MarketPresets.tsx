import React, { useState, useEffect } from 'react';
import { POPULAR_VEGETABLES } from '../data/vegetables';
import { VegetablePreset, CategoryType } from '../types';
import { Search, Sparkles, Plus, X, Trash2, ShoppingBag, Store } from 'lucide-react';

interface MarketPresetsProps {
  onSelectVegetable: (veg: VegetablePreset) => void;
  selectedVegId?: string;
}

const LOCAL_STORAGE_CUSTOM_ITEMS_KEY = 'sabzi_calculator_custom_products';

export const MarketPresets: React.FC<MarketPresetsProps> = ({
  onSelectVegetable,
  selectedVegId,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Custom products state persisted in localStorage
  const [customItems, setCustomItems] = useState<VegetablePreset[]>(() => {
    try {
      const saved = localStorage.getItem(LOCAL_STORAGE_CUSTOM_ITEMS_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Add custom item form state
  const [newName, setNewName] = useState('');
  const [newHindiName, setNewHindiName] = useState('');
  const [newPrice, setNewPrice] = useState<string | number>('');
  const [newCategory, setNewCategory] = useState<CategoryType>('grocery');
  const [newIcon, setNewIcon] = useState('🛒');

  useEffect(() => {
    try {
      localStorage.setItem(LOCAL_STORAGE_CUSTOM_ITEMS_KEY, JSON.stringify(customItems));
    } catch (e) {
      console.error('Failed to save custom items to localStorage', e);
    }
  }, [customItems]);

  const allPresets = [...POPULAR_VEGETABLES, ...customItems];

  const filteredPresets = allPresets.filter((veg) => {
    const matchesSearch =
      veg.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (veg.hindiName && veg.hindiName.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory =
      selectedCategory === 'all' || veg.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const handleAddCustomProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim() || !newPrice || Number(newPrice) <= 0) return;

    const customProd: VegetablePreset = {
      id: `custom-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      name: newName.trim(),
      hindiName: newHindiName.trim() || undefined,
      defaultPriceKg: Number(newPrice),
      category: newCategory,
      icon: newIcon || '🛒',
      isCustom: true,
    };

    setCustomItems((prev) => [customProd, ...prev]);
    onSelectVegetable(customProd);

    // Reset form
    setNewName('');
    setNewHindiName('');
    setNewPrice('');
    setNewCategory('grocery');
    setNewIcon('🛒');
    setShowAddModal(false);
  };

  const handleDeleteCustomItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setCustomItems((prev) => prev.filter((item) => item.id !== id));
  };

  const emojiChoices = ['🛒', '🥛', '🧀', '🍞', '🍎', '🍚', '🧈', '📦', '🧴', '🍪', '🍫', '🧃', '🫘', '🥔', '🧅', '🍅', '🌶️', '🥩', '🧼'];

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-4 sm:p-5 shadow-sm space-y-4">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-600" />
            Product & Vegetable Catalog
          </h2>
          <p className="text-xs text-slate-500">
            Click any item to load name & rate, or add custom supermarket products
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Add Product Button */}
          <button
            id="open-add-product-modal-btn"
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-xl transition-colors shadow-2xs"
          >
            <Plus className="w-4 h-4" />
            Add New Product
          </button>

          {/* Search Input */}
          <div className="relative min-w-[160px] sm:min-w-[190px]">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              id="search-vegetables-input"
              type="text"
              placeholder="Search (Aloo, Milk...)"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
        <button
          onClick={() => setSelectedCategory('all')}
          className={`px-3 py-1 rounded-lg transition-colors whitespace-nowrap font-medium ${
            selectedCategory === 'all'
              ? 'bg-emerald-700 text-white shadow-2xs'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          All Items ({allPresets.length})
        </button>
        <button
          onClick={() => setSelectedCategory('root')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'root'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🥔 Vegetables & Roots
        </button>
        <button
          onClick={() => setSelectedCategory('dairy')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'dairy'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🥛 Dairy & Bakery
        </button>
        <button
          onClick={() => setSelectedCategory('grocery')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'grocery'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🌾 Groceries & Grains
        </button>
        <button
          onClick={() => setSelectedCategory('snacks')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'snacks'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🍪 Snacks & Biscuits
        </button>
        <button
          onClick={() => setSelectedCategory('household')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'household'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🧴 Household Essentials
        </button>
        <button
          onClick={() => setSelectedCategory('spices')}
          className={`px-2.5 py-1 rounded-lg transition-colors whitespace-nowrap ${
            selectedCategory === 'spices'
              ? 'bg-emerald-700 text-white shadow-2xs font-medium'
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200/80'
          }`}
        >
          🧄 Spices & Oils
        </button>
      </div>

      {/* Grid of Product Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-8 gap-2">
        {filteredPresets.map((veg) => {
          const isSelected = selectedVegId === veg.id;
          return (
            <button
              key={veg.id}
              id={`preset-btn-${veg.id}`}
              onClick={() => onSelectVegetable(veg)}
              className={`relative flex flex-col items-start p-2.5 rounded-xl border text-left transition-all group hover:scale-[1.02] ${
                isSelected
                  ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20 shadow-xs'
                  : 'border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/30 bg-white'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <span className="text-xl group-hover:scale-110 transition-transform">
                  {veg.icon}
                </span>
                <span className="text-[10px] font-bold text-emerald-800 bg-emerald-100/90 px-1.5 py-0.5 rounded-md font-mono">
                  ₹{veg.defaultPriceKg}/kg
                </span>
              </div>

              <span className="text-xs font-semibold text-slate-800 line-clamp-1 leading-tight">
                {veg.name}
              </span>

              {veg.hindiName && (
                <span className="text-[10px] text-slate-500 line-clamp-1">
                  {veg.hindiName.split('/')[0]}
                </span>
              )}

              {veg.isCustom && (
                <div className="flex items-center justify-between w-full mt-1.5 pt-1 border-t border-slate-100">
                  <span className="text-[9px] uppercase font-bold text-emerald-700 bg-emerald-50 px-1 py-0.2 rounded">
                    Custom
                  </span>
                  <button
                    id={`delete-custom-item-${veg.id}`}
                    onClick={(e) => handleDeleteCustomItem(veg.id, e)}
                    className="text-slate-400 hover:text-rose-600 p-0.5 rounded hover:bg-rose-50 transition-colors"
                    title="Delete item"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Add New Custom Product Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold">
                  <Store className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">Add Custom Supermarket Product</h3>
                  <p className="text-xs text-slate-500">Create new products for your store catalog</p>
                </div>
              </div>
              <button
                id="close-add-modal-btn"
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-slate-700 p-1 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddCustomProduct} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Product Name <span className="text-emerald-600">*</span>
                </label>
                <input
                  id="custom-product-name-input"
                  type="text"
                  required
                  placeholder="e.g. Amul Butter 100g or Fortune Oil"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Rate per kg / unit (₹) <span className="text-emerald-600">*</span>
                  </label>
                  <input
                    id="custom-product-price-input"
                    type="number"
                    required
                    min="1"
                    step="0.5"
                    placeholder="e.g. 120"
                    value={newPrice}
                    onChange={(e) => setNewPrice(e.target.value)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-bold font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                    Category
                  </label>
                  <select
                    id="custom-product-category-select"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as CategoryType)}
                    className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                  >
                    <option value="grocery">🌾 Groceries & Grains</option>
                    <option value="dairy">🥛 Dairy & Bakery</option>
                    <option value="snacks">🍪 Snacks & Biscuits</option>
                    <option value="household">🧴 Household Essentials</option>
                    <option value="spices">🧄 Spices & Oils</option>
                    <option value="root">🥔 Vegetables & Roots</option>
                    <option value="fruit-veg">🍅 Fruits & Vegetables</option>
                    <option value="other">📦 Other Items</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Optional Local / Hindi Name
                </label>
                <input
                  id="custom-product-hindi-input"
                  type="text"
                  placeholder="e.g. Makkhan / मक्खन"
                  value={newHindiName}
                  onChange={(e) => setNewHindiName(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1">
                  Choose Icon / Emoji
                </label>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200">
                  {emojiChoices.map((emo) => (
                    <button
                      key={emo}
                      type="button"
                      onClick={() => setNewIcon(emo)}
                      className={`w-8 h-8 rounded-lg text-base flex items-center justify-center transition-transform ${
                        newIcon === emo ? 'bg-emerald-600 text-white scale-110 shadow-xs' : 'hover:bg-slate-200'
                      }`}
                    >
                      {emo}
                    </button>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  Cancel
                </button>
                <button
                  id="save-custom-product-btn"
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  Save Product to Catalog
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

