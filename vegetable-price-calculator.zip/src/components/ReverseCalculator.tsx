import React, { useState } from 'react';
import { calculateGramsForBudget } from '../utils/calculator';
import { ShoppingBag, ArrowRight, IndianRupee, Scale, Sparkles } from 'lucide-react';

interface ReverseCalculatorProps {
  initialItem?: string;
  initialKgPrice?: number;
}

export const ReverseCalculator: React.FC<ReverseCalculatorProps> = ({
  initialItem = 'Ginger',
  initialKgPrice = 120,
}) => {
  const [vegItem, setVegItem] = useState<string>(initialItem);
  const [kgPrice, setKgPrice] = useState<number | string>(initialKgPrice);
  const [budget, setBudget] = useState<number | string>(50);

  const numKgPrice = parseFloat(String(kgPrice)) || 0;
  const numBudget = parseFloat(String(budget)) || 0;

  const result = calculateGramsForBudget(numBudget, numKgPrice);

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 p-5 sm:p-6 shadow-sm max-w-3xl mx-auto space-y-6">
      
      <div className="flex items-center gap-3 pb-4 border-b border-slate-100">
        <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold">
          <ShoppingBag className="w-5 h-5" />
        </div>
        <div>
          <h2 className="text-base font-bold text-slate-800 flex items-center gap-2">
            Fixed Budget to Grams Weight Calculator
          </h2>
          <p className="text-xs text-slate-500">
            Find out how many grams/kg of a vegetable you get for a given budget amount (₹)
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Input 1: Item Name */}
        <div>
          <label htmlFor="reverse-item-input" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Vegetable Name
          </label>
          <input
            id="reverse-item-input"
            type="text"
            value={vegItem}
            onChange={(e) => setVegItem(e.target.value)}
            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:border-emerald-500"
            placeholder="e.g. Ginger, Garlic, Chili"
          />
        </div>

        {/* Input 2: Price per kg */}
        <div>
          <label htmlFor="reverse-kg-price-input" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            1 kg Price (₹)
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">₹</span>
            <input
              id="reverse-kg-price-input"
              type="number"
              min="0"
              value={kgPrice}
              onChange={(e) => setKgPrice(e.target.value)}
              className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {/* Input 3: Available Money / Budget */}
        <div>
          <label htmlFor="reverse-budget-input" className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
            Your Budget / Cash (₹)
          </label>
          <div className="relative">
            <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-amber-600 text-sm">₹</span>
            <input
              id="reverse-budget-input"
              type="number"
              min="0"
              value={budget}
              onChange={(e) => setBudget(e.target.value)}
              className="w-full pl-8 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:border-emerald-500"
              placeholder="e.g. 20, 50, 100"
            />
          </div>
          
          {/* Preset money chips */}
          <div className="flex gap-1 mt-1.5">
            {[10, 20, 30, 50, 100, 200].map((amt) => (
              <button
                key={amt}
                id={`budget-chip-${amt}`}
                onClick={() => setBudget(amt)}
                className="px-2 py-0.5 text-[10px] font-semibold bg-slate-100 hover:bg-amber-100 hover:text-amber-900 rounded-md border border-slate-200 transition-colors"
              >
                ₹{amt}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Result Display Box */}
      <div className="bg-gradient-to-r from-emerald-900 to-teal-950 rounded-2xl p-6 text-white shadow-md border border-emerald-800">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          
          <div>
            <span className="text-[10px] uppercase tracking-widest font-bold text-emerald-300 bg-emerald-800/80 px-2.5 py-1 rounded-md">
              You Get Exactly
            </span>
            <div className="text-3xl sm:text-4xl font-black text-white mt-2 flex items-baseline gap-2">
              <span>{result.grams} Grams</span>
              <span className="text-sm font-medium text-emerald-300 font-mono">
                ({result.kg} kg)
              </span>
            </div>
            <p className="text-xs text-emerald-200/90 mt-1">
              For <span className="font-bold text-amber-300">₹{numBudget}</span> worth of{' '}
              <span className="font-semibold text-white capitalize">{vegItem || 'item'}</span> at ₹{numKgPrice}/kg.
            </p>
          </div>

          <div className="bg-emerald-950/80 p-4 rounded-xl border border-emerald-800/80 text-xs font-mono space-y-1 self-stretch sm:self-auto min-w-[200px]">
            <div className="text-emerald-400 font-bold mb-1 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              Formula Breakdown:
            </div>
            <div className="text-slate-300">(Budget ÷ 1 kg Price) × 1000</div>
            <div className="text-amber-300 font-semibold">
              ({numBudget} ÷ {numKgPrice}) × 1000 = {result.grams}g
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
