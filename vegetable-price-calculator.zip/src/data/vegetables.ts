import { VegetablePreset } from '../types';

export const POPULAR_VEGETABLES: VegetablePreset[] = [
  // Vegetables
  { id: 'potato', name: 'Potato', hindiName: 'Aloo / आलू', defaultPriceKg: 30, category: 'root', icon: '🥔' },
  { id: 'onion', name: 'Onion', hindiName: 'Pyaz / प्याज', defaultPriceKg: 45, category: 'root', icon: '🧅' },
  { id: 'tomato', name: 'Tomato', hindiName: 'Tamatar / टमाटर', defaultPriceKg: 50, category: 'fruit-veg', icon: '🍅' },
  { id: 'green-chili', name: 'Green Chili', hindiName: 'Hari Mirch / हरी मिर्च', defaultPriceKg: 80, category: 'spices', icon: '🌶️' },
  { id: 'ginger', name: 'Ginger', hindiName: 'Adrak / अदरक', defaultPriceKg: 120, category: 'spices', icon: '🫚' },
  { id: 'garlic', name: 'Garlic', hindiName: 'Lahsun / लहसुन', defaultPriceKg: 200, category: 'spices', icon: '🧄' },
  { id: 'carrot', name: 'Carrot', hindiName: 'Gajar / गाजर', defaultPriceKg: 40, category: 'root', icon: '🥕' },
  { id: 'spinach', name: 'Spinach', hindiName: 'Palak / पालक', defaultPriceKg: 35, category: 'leafy', icon: '🥬' },
  { id: 'cucumber', name: 'Cucumber', hindiName: 'Kheera / खीरा', defaultPriceKg: 40, category: 'fruit-veg', icon: '🥒' },
  { id: 'cauliflower', name: 'Cauliflower', hindiName: 'Phool Gobi / फूलगोभी', defaultPriceKg: 60, category: 'other', icon: '🥦' },
  { id: 'coriander', name: 'Coriander Leaves', hindiName: 'Dhaniya / धनिया', defaultPriceKg: 100, category: 'leafy', icon: '🌿' },
  { id: 'lemon', name: 'Lemon', hindiName: 'Nimbu / नींबू', defaultPriceKg: 120, category: 'fruit-veg', icon: '🍋' },

  // Supermarket & Groceries
  { id: 'milk', name: 'Fresh Milk', hindiName: 'Doodh / दूध', defaultPriceKg: 64, category: 'dairy', icon: '🥛' },
  { id: 'paneer', name: 'Fresh Paneer', hindiName: 'Paneer / पनीर', defaultPriceKg: 380, category: 'dairy', icon: '🧀' },
  { id: 'curd', name: 'Dahi / Curd', hindiName: 'Dahi / दही', defaultPriceKg: 60, category: 'dairy', icon: '🥣' },
  { id: 'rice-basmati', name: 'Basmati Rice', hindiName: 'Chawal / चावल', defaultPriceKg: 95, category: 'grocery', icon: '🍚' },
  { id: 'atta-flour', name: 'Wheat Atta', hindiName: 'Aata / आटा', defaultPriceKg: 42, category: 'grocery', icon: '🌾' },
  { id: 'sugar', name: 'Sugar', hindiName: 'Chini / चीनी', defaultPriceKg: 44, category: 'grocery', icon: '🍬' },
  { id: 'mustard-oil', name: 'Cooking Oil', hindiName: 'Tel / तेल', defaultPriceKg: 140, category: 'grocery', icon: '🛢️' },
  { id: 'toor-dal', name: 'Toor / Arhar Dal', hindiName: 'Dal / दाल', defaultPriceKg: 150, category: 'grocery', icon: '🫘' },
  { id: 'bread', name: 'Brown / White Bread', hindiName: 'Bread / ब्रेड', defaultPriceKg: 40, category: 'snacks', icon: '🍞' },
  { id: 'biscuits', name: 'Cookies & Biscuits', hindiName: 'Biscuits / बिस्कुट', defaultPriceKg: 120, category: 'snacks', icon: '🍪' },
  { id: 'detergent', name: 'Washing Powder', hindiName: 'Detergent / डिटर्जेंट', defaultPriceKg: 110, category: 'household', icon: '🧴' },
];

export const WEIGHT_PRESETS = [
  { label: '50g', grams: 50 },
  { label: '100g', grams: 100 },
  { label: '250g (1/4 kg)', grams: 250 },
  { label: '500g (1/2 kg)', grams: 500 },
  { label: '750g (3/4 kg)', grams: 750 },
  { label: '1 kg (1000g)', grams: 1000 },
  { label: '1.5 kg', grams: 1500 },
  { label: '2 kg', grams: 2000 },
  { label: '5 kg', grams: 5000 },
];
