import React, { useState } from 'react';
import { Header } from './components/Header';
import { MarketPresets } from './components/MarketPresets';
import { VegetableCalculator } from './components/VegetableCalculator';
import { BillReceipt } from './components/BillReceipt';
import { ReverseCalculator } from './components/ReverseCalculator';
import { PriceMatrix } from './components/PriceMatrix';
import { VegetablePreset, BillItem, UnitType } from './types';
import { Scale, Code2, Sparkles, Terminal, Heart } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'calculator' | 'multi-bill' | 'budget' | 'matrix'>('calculator');
  
  // Single calculator state
  const [item, setItem] = useState<string>('Tomato');
  const [kgPrice, setKgPrice] = useState<number | string>(50);
  const [quantity, setQuantity] = useState<number | string>(250);
  const [unit, setUnit] = useState<UnitType>('g');
  const [selectedVegId, setSelectedVegId] = useState<string | undefined>('tomato');

  // Multi-item cart
  const [cartItems, setCartItems] = useState<BillItem[]>([]);

  const handleSelectVegetable = (veg: VegetablePreset) => {
    setItem(veg.name);
    setKgPrice(veg.defaultPriceKg);
    setSelectedVegId(veg.id);
  };

  const handleAddToCart = (newItem: BillItem) => {
    setCartItems((prev) => [newItem, ...prev]);
  };

  const handleRemoveCartItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateCartItemQuantity = (id: string, newGrams: number) => {
    setCartItems((prev) =>
      prev.map((item) => {
        if (item.id === id) {
          const safeGrams = Math.max(0, newGrams);
          const newTotalPrice = (item.kgPrice / 1000) * safeGrams;
          return {
            ...item,
            customerGrams: safeGrams,
            totalPrice: newTotalPrice,
          };
        }
        return item;
      })
    );
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  return (
    <div className="min-h-screen bg-slate-100/80 text-slate-900 font-sans flex flex-col selection:bg-emerald-200 selection:text-emerald-900">
      
      {/* App Header */}
      <Header
        cartItemCount={cartItems.length}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        
        {/* TAB 1: Single Item Calculator View */}
        {activeTab === 'calculator' && (
          <div className="space-y-6">
            
            {/* Quick Market Presets Grid */}
            <MarketPresets
              onSelectVegetable={handleSelectVegetable}
              selectedVegId={selectedVegId}
            />

            {/* Core Interactive Calculator */}
            <VegetableCalculator
              item={item}
              setItem={(val) => {
                setItem(val);
                setSelectedVegId(undefined);
              }}
              kgPrice={kgPrice}
              setKgPrice={setKgPrice}
              quantity={quantity}
              setQuantity={setQuantity}
              unit={unit}
              setUnit={setUnit}
              onAddToCart={handleAddToCart}
            />

          </div>
        )}

        {/* TAB 2: Multi-Item Customer Bill / Cart */}
        {activeTab === 'multi-bill' && (
          <BillReceipt
            items={cartItems}
            onRemoveItem={handleRemoveCartItem}
            onUpdateItemQuantity={handleUpdateCartItemQuantity}
            onClearCart={handleClearCart}
            onSwitchToCalculator={() => setActiveTab('calculator')}
          />
        )}

        {/* TAB 3: Reverse Budget to Weight Calculator */}
        {activeTab === 'budget' && (
          <div className="space-y-6">
            <ReverseCalculator
              initialItem={item}
              initialKgPrice={typeof kgPrice === 'number' ? kgPrice : parseFloat(kgPrice) || 50}
            />
          </div>
        )}

        {/* TAB 4: Weight-Price Reference Matrix */}
        {activeTab === 'matrix' && (
          <div className="space-y-6">
            <PriceMatrix
              item={item}
              kgPrice={typeof kgPrice === 'number' ? kgPrice : parseFloat(kgPrice) || 50}
            />
          </div>
        )}

      </main>

      {/* Footer / Formula Documentation */}
      <footer className="bg-slate-900 text-slate-400 text-xs border-t border-slate-800 py-6 mt-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded bg-emerald-600/20 text-emerald-400 flex items-center justify-center font-bold">
              <Scale className="w-3.5 h-3.5" />
            </div>
            <span className="font-semibold text-slate-300">
              Sabzi Weight & Price Calculator
            </span>
          </div>

          <div className="flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300 font-mono text-[11px]">
            <Terminal className="w-3.5 h-3.5 text-emerald-400" />
            <span>price_per_gram = kg_price / 1000 &bull; total_price = price_per_gram * customer_grams</span>
          </div>

          <div className="text-[11px] text-slate-500 flex items-center gap-1">
            Built with React, Tailwind CSS & Precision Math
          </div>

        </div>
      </footer>

    </div>
  );
}
