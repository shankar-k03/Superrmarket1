export type CategoryType =
  | 'root'
  | 'leafy'
  | 'fruit-veg'
  | 'spices'
  | 'dairy'
  | 'grocery'
  | 'snacks'
  | 'household'
  | 'other';

export interface VegetablePreset {
  id: string;
  name: string;
  hindiName?: string;
  defaultPriceKg: number;
  category: CategoryType;
  icon: string; // lucide icon name or emoji fallback
  isCustom?: boolean;
  unit?: 'kg' | 'pcs' | 'g';
}

export type PaymentMethod = 'cash' | 'upi';

export interface BillItem {
  id: string;
  item: string;
  kgPrice: number;
  customerGrams: number;
  pricePerGram: number;
  totalPrice: number;
  unit: 'g' | 'kg' | 'pcs';
  timestamp: Date;
}

export type UnitType = 'g' | 'kg' | 'pcs';

export interface CalculationInput {
  item: string;
  kgPrice: number;
  quantity: number;
  unit: UnitType;
}

export interface CalculationOutput {
  item: string;
  customerGrams: number;
  kgPrice: number;
  pricePerGram: number;
  totalPrice: number;
  formattedTotalPrice: string;
}

