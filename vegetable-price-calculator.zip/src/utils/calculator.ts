import { UnitType, CalculationOutput } from '../types';

/**
 * Calculates total vegetable price based on per-kg rate and required weight/quantity.
 * Implements the exact formula from user logic:
 * price_per_gram = kg_price / 1000
 * total_price = price_per_gram * customer_grams
 */
export function calculateVegetablePrice(
  item: string,
  kgPrice: number,
  quantity: number,
  unit: UnitType
): CalculationOutput {
  const safeKgPrice = Math.max(0, Number(kgPrice) || 0);
  const safeQuantity = Math.max(0, Number(quantity) || 0);

  // Convert quantity to customer_grams
  let customerGrams = 0;
  if (unit === 'kg') {
    customerGrams = safeQuantity * 1000;
  } else if (unit === 'g') {
    customerGrams = safeQuantity;
  } else {
    // 'pcs' or count - treat as grams if weight equivalent or direct calculation
    customerGrams = safeQuantity;
  }

  const pricePerGram = safeKgPrice / 1000;
  const totalPrice = pricePerGram * customerGrams;

  const formattedTotalPrice = `₹${totalPrice.toFixed(2)}`;

  return {
    item: item.trim() || 'Vegetable Item',
    customerGrams,
    kgPrice: safeKgPrice,
    pricePerGram,
    totalPrice,
    formattedTotalPrice,
  };
}

/**
 * Calculates weight in grams for a given budget amount (₹).
 * Formula: grams = (budget / kg_price) * 1000
 */
export function calculateGramsForBudget(budget: number, kgPrice: number): {
  grams: number;
  kg: number;
  exactPrice: number;
} {
  const safeBudget = Math.max(0, Number(budget) || 0);
  const safeKgPrice = Math.max(0.001, Number(kgPrice) || 0);

  const grams = (safeBudget / safeKgPrice) * 1000;
  const kg = grams / 1000;
  const exactPrice = (safeKgPrice / 1000) * grams;

  return {
    grams: Math.round(grams * 10) / 10,
    kg: Math.round(kg * 1000) / 1000,
    exactPrice,
  };
}

/**
 * Formats Python console receipt style string as requested by the user script.
 */
export function generateConsoleBillText(
  item: string,
  customerGrams: number,
  totalPrice: number
): string {
  return `----- BILL -----
Item: ${item || 'Vegetable'}
Quantity: ${customerGrams} grams
Total Price: ₹${totalPrice.toFixed(2)}`;
}

/**
 * Formats full itemized receipt string for multiple items.
 */
export function generateMultiItemReceiptText(
  items: { item: string; customerGrams: number; totalPrice: number; kgPrice: number }[],
  storeName: string = 'GREEN VEGETABLE MARKET',
  gstRate: number = 0,
  paymentMethod: 'cash' | 'upi' = 'cash',
  paymentStatus: 'paid' | 'pending' = 'pending',
  upiId?: string
): string {
  const dateStr = new Date().toLocaleString('en-IN', {
    dateStyle: 'medium',
    timeStyle: 'short',
  });

  const subtotal = items.reduce((sum, i) => sum + i.totalPrice, 0);
  const taxAmount = (subtotal * gstRate) / 100;
  const grandTotal = subtotal + taxAmount;

  let text = `=================================\n`;
  text += `   ${storeName.toUpperCase()}   \n`;
  text += `   Fresh Vegetables & Daily Essentials  \n`;
  text += `=================================\n`;
  text += `Date: ${dateStr}\n`;
  text += `---------------------------------\n`;
  text += `ITEM         QTY(g)   RATE/kg   TOTAL\n`;
  text += `---------------------------------\n`;

  items.forEach((it) => {
    const namePadded = it.item.padEnd(12, ' ').slice(0, 12);
    const qtyPadded = `${it.customerGrams}g`.padStart(7, ' ');
    const ratePadded = `₹${it.kgPrice}`.padStart(8, ' ');
    const totalPadded = `₹${it.totalPrice.toFixed(2)}`.padStart(8, ' ');
    text += `${namePadded} ${qtyPadded} ${ratePadded} ${totalPadded}\n`;
  });

  text += `---------------------------------\n`;
  text += `TOTAL ITEMS: ${items.length}\n`;
  text += `SUBTOTAL   : ₹${subtotal.toFixed(2)}\n`;
  if (gstRate > 0) {
    text += `GST / TAX (${gstRate}%): ₹${taxAmount.toFixed(2)}\n`;
  }
  text += `GRAND TOTAL: ₹${grandTotal.toFixed(2)}\n`;
  text += `---------------------------------\n`;
  if (paymentMethod === 'upi') {
    text += `PAYMENT    : ONLINE UPI (QR CODE)\n`;
    if (upiId) text += `UPI ID     : ${upiId}\n`;
    text += `STATUS     : ${paymentStatus === 'paid' ? 'SUCCESS / PAID ✓' : 'PENDING PAYMENT ⏳'}\n`;
  } else {
    text += `PAYMENT    : CASH ON DELIVERY (COD)\n`;
    text += `STATUS     : ${paymentStatus === 'paid' ? 'RECEIVED ✓' : 'COLLECT CASH ON DELIVERY'}\n`;
  }
  text += `=================================\n`;
  text += `   Thank You! Visit Again! 🙏   \n`;
  text += `=================================\n`;

  return text;
}
